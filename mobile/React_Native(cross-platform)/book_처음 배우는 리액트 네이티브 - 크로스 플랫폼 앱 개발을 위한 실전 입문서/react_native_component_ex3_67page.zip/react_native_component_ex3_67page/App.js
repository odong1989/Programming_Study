import * as React from 'react';
import { Text, View, StyleSheet } from 'react-native';
import Constants from 'expo-constants';
import { StatusBar } from 'expo-status-bar';

  //JSX는 내부에서 자바스크립트의 변수를 전달할 수 있다.


export default function App() {
  const name = 'Bongjun';   //JSX는 내부에서 자바스크립트의 변수를 전달할 수 있다.

  return (
    <View style={styles.container}>
      <Text style={styles.text}>
        My name is {name}
      </Text>
        <StatusBar style="auto" />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    paddingTop: Constants.statusBarHeight,
    backgroundColor: '#ecf0f1',
    padding: 8,
  },
  paragraph: {
    margin: 24,
    fontSize: 18,
    fontWeight: 'bold',
    textAlign: 'center',
  },
});
