import * as React from 'react';
import { Text, View, StyleSheet } from 'react-native';
import Constants from 'expo-constants';
import { StatusBar } from 'expo-status-bar';
import {Fragment} from 'react';
/*
    1. <View>컴포넌트
    1.1. <View>는 UI를 구성하는 가장 기본적인 요소이다.
    1.2. <View>는 웹의 div와 비슷한 역할을 한다.

    2. <Fragment>컴포넌트
    2.1. <Fragment>는 <View>처럼 특정 역할을 하는 컴포넌이다.
    2.2. <Fragment>는 여러 개의 컴포넌트를 반환하고 싶은 경우에 사용한다.
    2.3. <Fragment>는 <></>으로 간략하게 적을 수 있다.

*/
export default function App() {
  return (
    <Fragment>
      <Text>
        Open up App.js to start working on your app!
      </Text>
      <StatusBar style="auto" />
    </Fragment>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    paddingTop: Constants.statusBarHeight,
    backgroundColor: '#ecf0f1',
    padding: 8,
  },
  paragraph: {
    margin: 24,
    fontSize: 18,
    fontWeight: 'bold',
    textAlign: 'center',
  },
});
