/*
  codeLab_w1_L2_ex3
  스타일 설명(const styles, container)
 */

import * as React from 'react';
import { Text, View, StyleSheet } from 'react-native';
import Constants from 'expo-constants';

/*
    스타일 설명(const styles, container)
*/
// 영상타임 : 11:22 ~ 11:23

 
export default function App() {
  return (
    <View style={styles.container}>
      <Text>
        이 뷰의 스타일은 'const styles'에서 생성된
        container(00번 라인)의 스타일을 받아서 적용한 것이다.
        HTML로 비유하자면 미리 지정한 css를 받아서 적용한 것과 비슷하다 볼 수 있겠다.
      </Text>
    </View>    
  );
}

//
const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    paddingTop: Constants.statusBarHeight,
    backgroundColor: '#ecf0f1',
    padding: 20,
  },
  paragraph: {
    margin: 24,
    fontSize: 40,
    fontWeight: 'bold',
    textAlign: 'center',
  },
});
