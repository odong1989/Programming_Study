/*
  codeLab_w1_L2_ex2
  '풀옵스(중괄호{}를 사용하면 자바스크립트 코드를 사용할 수 있는 기능)' 설명
*/

import * as React from 'react';
import { Text, View, StyleSheet } from 'react-native';
import Constants from 'expo-constants';


//영상시간 : 11:18~11:21
/* 중괄호{}를 사용하면 자바스크립트 코드를 사용할 수 있습니다.
   이를 '풀옵스'라고 부릅니다.

   한 마디로 {}내에 있는 코드들은 자바스크립트의 규칙대로 작성이 가능합니다.
*/

  //예5 변수-함수외 글로벌 변수.
  var greetingGlobal = 'Hello, React Native by greeting var Global';

  //예6 함수-글로벌 함수인 경우
  function greetingFunctionGlobal(){
    return 'Hello, React Native by Function Global';
  }

export default function App() {

  //예3 변수(let greeting)를 선언하여 로드하는 경우
  let greetingLocal = 'Hello, React Native by let greeting Local';

  //예4 함수의 형태로 선언한 경우
  function greetingFunctionLocal(){
    return 'Hello, React Native By function Local'
  }

  return (
    <View style={styles.container}>
      <Text>
        {'중괄호를 사용하면 자바스크립트 방식으로 작성이 가능합니다.'}
      </Text>

      <Text>
        {'예1) 문자열로 출력'}
        {'Hello, React native by String'}
      </Text>

      <Text>
        {'예2) 배열로 출력([] 활용)'}
        {['Hello', 'React Native', 'by Array'].join(' ') }
        {'[참고] join을 활용하면 배열의 문자들을 묶어서 출력하게 됩니다.'}
      </Text>


      <Text>
        {'예3) 변수를 집어넣어 출력하는 경우'}
        { greetingLocal }
      </Text>

      <Text>
        {'예4) 함수를 호출하여 출력하는 경우'}
        { greetingFunctionLocal() }
      </Text>


      <Text>
        {'예5) 글로벌 변수로 출력'}
        { greetingGlobal }
      </Text>

      <Text>
        {'예6) 글로벌 함수로 출력'}
        { greetingFunctionGlobal() }
      </Text>

    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    paddingTop: Constants.statusBarHeight,
    backgroundColor: '#ecf0f1',
    padding: 8,
  },
  paragraph: {
    margin: 24,
    fontSize: 18,
    fontWeight: 'bold',
    textAlign: 'center',
  },
});
