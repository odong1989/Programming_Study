/*
  codeLab_w1_L2_ex5
  (1)버튼임포트 (2)버튼배치 (3)버튼 액션주기
*/

import * as React from 'react';
import { Button, Text, View, StyleSheet } from 'react-native';
import Constants from 'expo-constants';


/* Button
  //단계1 : Button을 임포트.
  import { Button, Text, View, StyleSheet } from 'react-native';

  //단계2 : <View> 내에 버튼 기능 설정
    title : 버튼의 제목(버튼 내 텍스트).
            {}를 활용하여 자바스크립트 방식으로 텍스트를 선언해도 됩니다.
            [주의1] title에는 무조건 텍스트만 가능함.(이미지삽입은 불가)
            [주의2] 이미지를 버튼으로 활용하려면 다른 방법으로 해야합니다.
    onPress : 버튼이 클릭된 때 작동할 기능명시.

      <Button 
        title={"클릭(정규포맷)"} 
        onPress={ handlePress }> 
        //중괄호안에 자바스크립트 선언 가능하기에 함수명handlePress를
        //기입하면 작동하게 된다. 
      </Button>


*/


let greeting = 'Hello, React Native';

export default function App() {

  function handlePress(){
    alert('press!');
  }

  return (
    <View style={styles.container}>
      <Text style={styles.paragraph}>
        {greeting}
      </Text>

      <Button 
        title={"클릭(정규포맷)"} 
        onPress={ handlePress }>
      </Button>
      
      <Text style={styles.paragraph}> (구분용 간격 텍스트) </Text>

      <Button 
        title={"클릭2(xml약식포맷)"} 
        onPress={ handlePress }/>

      <Text style={styles.paragraph}> (구분용 간격 텍스트2) </Text>

      <Button 
        title={"클릭3(익명함수 선언)"} 
        onPress={ () => alert('annonymous function!') }/>


    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    paddingTop: Constants.statusBarHeight,
    backgroundColor: '#ecf0f1',
    padding: 8,
  },
  paragraph: {
    margin: 24,
    fontSize: 18,
    fontWeight: 'bold',
    textAlign: 'center',
  },
});
