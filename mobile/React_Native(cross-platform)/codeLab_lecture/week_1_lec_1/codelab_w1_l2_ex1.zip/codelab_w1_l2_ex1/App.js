/*
  codeLab_w1_L2_ex1
  구간별 자바스크립트 / xml 적용구간 안내
 */

import * as React from 'react';
import { Text, View, StyleSheet } from 'react-native';
import Constants from 'expo-constants';

//영상시간 11:10 ~ 11:17

//여기는 자바스크립트 적용구간_1입니다(자바스크립트 코드 기입가능.)
export default function App() {
  //여기는 자바스크립트 적용구간_2입니다(자바스크립트 코드 기입가능.)
  return (
    <View style={styles.container}>
    <Text>
      Hello React Native!
    </Text>
    <Text>
      View에 쓰이는 것은 xml내용입니다.
    </Text>
    <Text>
      사용할 요소에 대하여 태그를 명시해주어야 렌더링이 제대로 됩니다.
      그래서 Text태그를 사용해서 텍스트임을 명시해줘야 출력이 됩니다.
    </Text>

    <Text>
      'View'내에서 자바스크립트 코드를 활용하려면 '풀옵스(중괄호{}를 사용하면 자바스크립트 코드를 사용할 수 있는 기능) '를 사용해야 합니다.
    </Text>

    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    paddingTop: Constants.statusBarHeight,
    backgroundColor: '#ecf0f1',
    padding: 8,
  },
  paragraph: {
    margin: 24,
    fontSize: 18,
    fontWeight: 'bold',
    textAlign: 'center',
  },
});
