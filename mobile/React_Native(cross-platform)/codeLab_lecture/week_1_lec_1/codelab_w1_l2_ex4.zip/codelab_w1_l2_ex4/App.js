/*
  codeLab_w1_L2_ex4
  XML 규칙 예제(단축표현)& 특별문법 없음 안내
*/

import * as React from 'react';
import { Text, View, StyleSheet } from 'react-native';
import Constants from 'expo-constants';

/* XML 규칙 예제(단축표현)& 특별문법 없음 안내
   (1)React Native는 xml의 문법도 활용이 가능하다.  
      <View></View> : 일반적인 xml 표현법
      <View/>       : xml의 단축표현법

    (2)앵귤러나 뷰 처럼 특별한 별개의 문법(스페셜 어트리뷰트)은 없습니다. 
       (예1) ng:for
       (예2) v-for

    영상 11:22~11:25
*/
export default function App() {
  return (
    <View style={styles.container}>
      <Text style={styles.paragraph}>
        xml의 규칙중 하나인 단축표현을 쓸 수도 있습니다.
        Web에서 참고해주세요.(설명이 주석으로 씌여 있음)  
      </Text>

      <View></View>

      <View/>

    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    paddingTop: Constants.statusBarHeight,
    backgroundColor: '#ecf0f1',
    padding: 8,
  },
  paragraph: {
    margin: 24,
    fontSize: 18,
    fontWeight: 'bold',
    textAlign: 'center',
  },
});
