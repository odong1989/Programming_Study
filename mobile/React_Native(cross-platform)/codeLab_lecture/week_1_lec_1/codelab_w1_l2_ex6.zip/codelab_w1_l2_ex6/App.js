import * as React from 'react';
import { useState } from 'react';

import { Button, Text, View, StyleSheet } from 'react-native';
import Constants from 'expo-constants';

  /*기존의 코딩 방식은 전체부분에 미리 변수를 선언해 두고, 
    이를 ++처리를 하는 방식이 많이 활용되었습니다. 
    즉, 읽기&쓰기가 쌍방이 되었다는 애기입니다.
    우리가 ++처리등을 하는데 가능한 배경에는 데이터의 쌍방흐름(읽기&쓰기)이
    가능했기 때문이었습니다.

    대규모 푸로젝트를 하는데에는 쌍방향 흐름은 나쁘지 않았습ㄴ지다.
    문제는 너무 많은 리소스를 쓰게 하였고, 이로 인해 메모리 낭비가 많아
    자연히 성능 저하를 불러 일으켰습니다.(성능상 약점이 많은 방식이란 애기)
    이것은 모바일 기기에는 치명적인 성능저하를 일으키게 했습니다.

    그래서 리액트 네이티브는 데이터의 흐름이 한 방향으로만 흐르도록 합니다.
    이를 위해 useState();라는 것을 도입하게 됩니다.
    (정확히 말하자면 "stateHook을 사용한다"라고 합니다.)


    자세한 이해를 위헤서는 상태와 풀옵스에 대한 이해가 좀 더 필요합니다.

  */

export default function App() {
  //state(상태)
  let count =0; //리액트 네이티브에서는 동작불가.(쌍방향 방식을 쓰기때문)
  const [ onlyReadCount, setCount] = useState( 0 ); 
  //[읽기전용변수, 쓰기전용함수]의 파티플레이.
  //onlyReadCount : 읽기 전용 값.
  //setCount : 카운팅 전용 함수.

  return (
    <View style={styles.container}>
      <Text style={styles.paragraph}>
        쌍방향방식(읽기&쓰기 동시)
        <Text> count : {count} </Text>
      </Text>
      <Button
        title = {"일반적 증감식(카운트 증가않음)"}
        onPress ={() => count ++}> 
      </Button>

      <Text style={styles.paragraph}>
        단방향읽기(읽기, 쓰기 개별)
        <Text> onlyReadCount : {onlyReadCount} </Text>
      </Text>
      <Button
        title ={"단방향(setCount통해 증가)"}
        onPress = { () => setCount(onlyReadCount+1)}
      >

      </Button>



    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    paddingTop: Constants.statusBarHeight,
    backgroundColor: '#ecf0f1',
    padding: 8,
  },
  paragraph: {
    margin: 24,
    fontSize: 18,
    fontWeight: 'bold',
    textAlign: 'center',
  },
});
