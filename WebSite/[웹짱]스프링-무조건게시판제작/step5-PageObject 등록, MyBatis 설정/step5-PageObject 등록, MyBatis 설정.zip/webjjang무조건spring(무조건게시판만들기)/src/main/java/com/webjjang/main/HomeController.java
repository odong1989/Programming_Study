package com.webjjang.main;

import java.text.DateFormat;
import java.util.Date;
import java.util.Locale;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class HomeController {
	
	private static final Logger logger = LoggerFactory.getLogger(HomeController.class);
	
	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String home(Locale locale, Model model) {
		logger.info("Welcome home! The client locale is {}.", locale);
		
		Date date = new Date();
		DateFormat dateFormat = DateFormat.getDateTimeInstance(DateFormat.LONG, DateFormat.LONG, locale);
		String formattedDate = dateFormat.format(date);
		model.addAttribute("serverTime", formattedDate );


		return "home";
		/*
		servlet-context.xml의  <beans:bean class="org.springframework.web.servlet.view.InternalResourceViewResolver">에 
			<beans:property name="prefix" value="/WEB-INF/views/" />
		<beans:property name="suffix" value=".jsp" />
		위의 2개 설정에 의해 return이 작동하게 된다.
		
		즉, "/WEB-INF/views/" + Return 값 +  ".jsp"의 형태가 되며 
	        최종경로는 "/WEB-INF/views/home.jsp" 가 되는 것이다.
		*/

	}
	
}
