package com.webjjang.board.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;


//게시판(board) 관련 컨트롤러.
@Controller
@RequestMapping("/board")  //view의 페이지에서 board폴더로 빠지도록 해준다.
public class BoardController {
	//실행할 메서드 만들기

	// @GetMapping : URL을 입력해주는 설정이다. 이것이 없을경우  맴핑을 해줄 수가 없다.(URL을 입력하는 경우는 맵핑방식이 "GetMapping"이다)
	@GetMapping("/list.do") //"~.do"는 옛날 스프링 배우신분들의 스타일(영어의 do(하다)의 뜻으로 작성한듯하다.)이다. 그냥 "list"라고만 해도 무방하다.  
	public String list() {
		//로그 역할의 프린트문. 콘솔창에 나오게 된다.
		System.out.println("BoardController.list()에서 실행하고 있습니다.");
		
		
		return "board/list";
		/*
		servlet-context.xml의  <beans:bean class="org.springframework.web.servlet.view.InternalResourceViewResolver">에 
			<beans:property name="prefix" value="/WEB-INF/views/" />
			<beans:property name="suffix" value=".jsp" />
			위의 2개 설정에 의해 return이 작동하게 된다.
			
			즉, "/WEB-INF/views/" + Return 값 +  ".jsp"의 형태가 되며 
	        최종경로는 "/WEB-INF/views/board/list.jsp" 가 되는 것이다.	
		*/
	}
}
