package com.company.board.vo;

import java.util.Date;

public class BoardVO {
	private int no; //더 많은 데이터를 쓰려면 int보다는 long을 쓰는 경ㅇ우도 많다.
	private String title, content, wirter;
	private Date writeDate;
	private int hit;	//조회수 
	private String pw;
	
	public int getNo() {
		return no;
	}
	public void setNo(int no) {
		this.no = no;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public String getWirter() {
		return wirter;
	}
	public void setWirter(String wirter) {
		this.wirter = wirter;
	}
	public Date getWriteDate() {
		return writeDate;
	}
	public void setWriteDate(Date writeDate) {
		this.writeDate = writeDate;
	}
	public int getHit() {
		return hit;
	}
	public void setHit(int hit) {
		this.hit = hit;
	}
	public String getPw() {
		return pw;
	}
	public void setPw(String pw) {
		this.pw = pw;
	}
	
	@Override
	public String toString(){
		return "BoardVO [no="+ no 
			   +", title=" +title
			   +", content=" +content
			   +", wirter=" +wirter
			   +", writeDate=" +writeDate
			   +", hit=" +hit
			   +", pw=" +pw	+"]";	
	}
 
}
