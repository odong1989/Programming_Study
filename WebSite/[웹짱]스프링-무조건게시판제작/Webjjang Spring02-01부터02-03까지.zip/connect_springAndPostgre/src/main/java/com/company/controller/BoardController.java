package com.company.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.company.board.vo.BoardVO;
import com.webjjang.util.PageObject;

@Controller
@RequestMapping("/board")
public class BoardController {
		
	private final String MODEULE_NAME="board";
	
	//게시판 리스트(게시글 목록)
	@GetMapping("/list")
	public String list(Model model, PageObject pageObject) {
		return MODEULE_NAME+"/list";
	}
	
	//게시글 보기 
	@GetMapping("/view")
	public String view(Model model, PageObject pageObject, int no, int inc) {
		// inc : increase의 약자.
		//view?no=1&inc=1
		//http://localhost:8283/test/board/view?no=1&inc=1 이런식으로 작성해야 이동이 된다.
		//Webjjang Spring 02-02 무조건 검색 게시판 - Controller와 JSP(웹짱과 함께하는 스프링 영상의 15:27 참
		return MODEULE_NAME+"/view"; 
	}
	
	//게시판 글쓰기(Form) 
	@GetMapping("/write") //게시글 작식이다.
	public String writeForm(){  
		return MODEULE_NAME+"/write"; 
	}
	
	//게시판 글쓰기 처
	@PostMapping("/write") //작성된 게시글의 처리는 post방식이다.
	public String write(BoardVO vo){  
		//화면에 JSP페이지를 보여주지 않고 바로 리스트로 이동.
		return "redirect:list"; 
	}
	
	//게시판 글수정 폼(Form) 
	@GetMapping("/update") //게시글 작식이다.
	public String updateForm(Model model, int no, int inc){  
		return MODEULE_NAME+"/update"; 
	}
	
	//게시판 글수정 처리(필요 파라미터 : 제목/내용/작성자/비밀번호(확인용) )
	@PostMapping("/update") //작성된 게시글의 처리는 post방식이다.
	public String update(BoardVO vo){  
		//화면에 JSP페이지를 보여주지 않고 바로 리스트로 이동.
		return "redirect:view?no="+vo.getNo()+"inc=0"; 
	}
	
	//게시판 글 삭제(필요 파라미터 :글번호, 비밀번호(확인용))
	@PostMapping("delete")
	public String delete(BoardVO vo) {
		//화면에 JSP페이지를 보여주지 않고 바로 리스트로 이동.		
		return "redirect:list?no=" + vo.getNo()+"&inc=0";
	}
	
}
