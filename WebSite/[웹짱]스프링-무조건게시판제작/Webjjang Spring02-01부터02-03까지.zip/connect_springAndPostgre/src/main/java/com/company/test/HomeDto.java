package com.company.test;



public class HomeDto {

	private String account_idx;

	private String id;

	

	public String getAccount_idx(){

		return account_idx;

	}

	public void setAccount_idx(String account_idx){

		this.account_idx=account_idx;

	}

	public String getId(){

		return id;

	}

	public void setId(String id){

		this.id=id;

	}

}