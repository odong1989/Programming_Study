create table board
(
  no number primary key,
  title varchar2(300) not null,
  content varchar2(2000) not null,
  writer varchar2(30) not null,
  writeDate date default sysdate,
  hit number default 0,
  replyCnt number default 0,
  pw varchar2(30) not null
);

create table board_rep
(
  rno number primary key,
  no number references board(no),
  content varchar2(500) not null,
  writer varchar2(30) not null,
  writeDate date default sysdate,
  pw varchar2(30) not null
);

create sequence board_rep_seq;

create sequence board_seq;
