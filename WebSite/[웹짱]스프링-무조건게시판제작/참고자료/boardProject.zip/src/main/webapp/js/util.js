/**
 * 
 */

var business_process_tr_appendText = "<tr class='business_process last'>"
		+ "<td class='alignL'>"
		+ "<div class='filebox'>"
		+ "<input class='upload-name' name='business_process_multi' disabled='disabled'>"
		+ "<label for='ex_filename'>파일선택</label>"
		+ "<input type='file' id='ex_filename' class='upload-hidden'  name='business_process_multi' />"
		+ "</div>"
		+ "</td>"
		+ "</tr>";

var budget_schedule_tr_appendText = "<tr class='budget_schedule'>"
		+ "<td><input type='text' name='budget_item' /></td>"
		+ "<td><input type='text' name='budget_detail'  /></td>"
		+ "<td><input type='text' name='budget_smal_detail'  /></td>"
		+ "<td><input type='text' name='budget_price'  /></td>"
		+ "<td><input type='text' class='full' name='budget_basis'  /></td>"
		+ "</tr>";

var field_schedule_tr_appendText = "<tr class='field_schedule last'>"
		+ "<td class='alignL'>"
		+ "<div class='filebox'>"
		+ "<input class='upload-name' name='field_schedule_multi' disabled='disabled'>"
		+ "<label for='ex_filename'>파일선택</label>"
		+ "<input type='file' id='ex_filename' class='upload-hidden' name='field_schedule_multi' />"
		+ "</div>"
		+ "</td>"
		+ "</tr>"


function selectAppendTag(moduleName){
//	alert("selectAppendTag().moduleName:"+moduleName);
	if(moduleName == "business_process") return business_process_tr_appendText;
	else if (moduleName == "budget_schedule") return budget_schedule_tr_appendText;
	else if (moduleName == "field_schedule") return field_schedule_tr_appendText;
}

function th_rowspan_upDown(table, tr_class_name, upDown){
	var first_tr = table.find("."+tr_class_name+":first");
	var th = first_tr.find("th");
//	alert(th.text());
	if(th.attr("rowspan") == 1 && upDown == -1){
		alert("파일 첨부는 하나 이상 있어야 합니다.");
		return false;
	}
	th.attr("rowspan", Number(th.attr("rowspan")) + upDown);
	return first_tr;
}

$(function(){
	$(".appendTrRowspanBtn").click(function(){
//		alert("test");
		var tr_class_name = $(this).data("modulename");
//		alert(tr_class_name);
		var table = $(this).closest(".conBlock").find("table");
//		alert(table.html());
		var first_tr = th_rowspan_upDown(table, tr_class_name, +1);
		var appendTag = selectAppendTag(tr_class_name);
//		alert("appendTrRowspanBtn Event. appendTag:"+appendTag);
		if(first_tr.hasClass("last")){
			first_tr.removeClass("last");
			first_tr.after(appendTag);
		}else{
			table.find("."+tr_class_name+":last").after(appendTag);
		}
		
	});
	
	$(".removeTrRowspanBtn").click(function(){
//		alert("test");
		var tr_class_name = $(this).data("modulename");
//		alert(tr_class_name);
		var table = $(this).closest(".conBlock").find("table");
		if(!th_rowspan_upDown(table, tr_class_name, - 1)) return;
		$("."+tr_class_name+":last").remove();
		table.find("."+tr_class_name+":last").addClass("last");
		
	});
});

