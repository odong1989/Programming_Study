package com.webjjang.board.service;

import java.util.List;

import javax.inject.Inject;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.webjjang.board.mapper.BoardMapper;
import com.webjjang.board.vo.BoardVO;

import lombok.AllArgsConstructor;

@Service
@Qualifier("bs")
@AllArgsConstructor  // 생성자를 이용한 DI 적용
public class BoardServiceImpl implements BoardService {

	private BoardMapper mapper;
	
	@Override
	public List<BoardVO> list() {
		// TODO Auto-generated method stub
		return mapper.list();
	}

	@Override
	public Integer write(BoardVO vo) {
		// TODO Auto-generated method stub
		return mapper.write(vo);
	}

	@Override
	public BoardVO view(Long no) {
		// TODO Auto-generated method stub
		mapper.increaseHit(no);
		return mapper.view(no);
	}

	@Override
	public Integer update(BoardVO vo) {
		// TODO Auto-generated method stub
		return mapper.update(vo);
	}

	@Override
	public Integer delete(BoardVO vo) {
		// TODO Auto-generated method stub
		return mapper.delete(vo);
	}

}
