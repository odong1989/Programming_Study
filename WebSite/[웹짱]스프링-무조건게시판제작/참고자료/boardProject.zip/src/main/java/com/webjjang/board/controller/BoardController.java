package com.webjjang.board.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.webjjang.board.service.BoardService;
import com.webjjang.board.vo.BoardVO;

/*
 * 페이지 처리가 되어 있지 않는 게시판 시스템 개발 
 */

@Controller
@RequestMapping("/board")
public class BoardController {

	@Autowired
	@Qualifier("bs")
	private BoardService service;
	
	private String MODULE_NAME = "board";
	
	// 게시판 리스트
	@GetMapping("/list.do")
	public String list(Model model) {
		model.addAttribute("list", service.list());
		// "/WEB-INF/views/" + "board/list" + ".jsp"
		return MODULE_NAME + "/list";
	}
	
	// 게시판  글쓰기 폼
	@GetMapping("/write.do")
	public String writeForm() {
		// "/WEB-INF/views/" + "board/write" + ".jsp"
		return MODULE_NAME + "/write";
	}
	
	// 게시판 글쓰기 처리
	@PostMapping("/write.do")
	public String write(BoardVO vo) {
		service.write(vo);
		// 글쓰기 처리 후 게시판 리스트로 자동 이동시킨다.
		return "redirect:list.do";
	}
	
	// 게시판 글보기
	@GetMapping("/view.do")
	public String view(Model model, long no) {
		model.addAttribute("vo", service.view(no));
		// "/WEB-INF/views/" + "board/view" + ".jsp"
		return MODULE_NAME + "/view";
	}
	
	// 게시판 글수정 폼
	@GetMapping("/update.do")
	public String updateForm(Model model, long no) {
		model.addAttribute("vo", service.view(no));
		// "/WEB-INF/views/" + "board/update" + ".jsp"
		return MODULE_NAME + "/update";
	}
	
	// 게시판 글수정 처리
	@PostMapping("/update.do")
	public String update(BoardVO vo) {
		Integer result = service.update(vo);
		if(result == 1) {
			// 정상적인 글수정 처리 후 게시판 글보기로 자동 이동시킨다.
			return "redirect:view.do?no=" + vo.getNo();
		}
		// 수정이 안된 경우 비밀번호가 틀린 경우이므로 입력정보 오류 페이지로 자동 이동시킨다.
		return "redirect:/error/error_wrongPW";
	}
	
	// 게시판 글삭제 - 글번호, 비밀번호를 받는다.
	@GetMapping("/delete.do")
	public String delete(BoardVO vo) {
		Integer result = service.delete(vo);
		if(result == 1) {
			// 정상적인 글삭제 처리 후 게시판 리스트로 자동 이동시킨다.
			return "redirect:list.do";
		}
		// 삭제가 안된 경우 비밀번호가 틀린 경우이므로 입력정보 오류 페이지로 자동 이동시킨다.
		return "redirect:/error/error_wrongPW";
		
	}
	
}
